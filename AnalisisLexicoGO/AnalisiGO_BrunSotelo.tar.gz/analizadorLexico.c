#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "tablaSimbolos.h"
#include "sistemaEntrada.h"
#include "definiciones.h"

#define TAM 5

tabla nodo;
tipoelem lexemaActual;
char caracterActual, cAnterior;
int tamActual;

void reservaLexema(){
    realloc(lexemaActual, strlen(lexemaActual)+TAM); //Se realoja la memoria   
    tamActual+=TAM; //Se actualiza el tamaño actual del buffer
}

void alfaNum(){    
    do{
        if(strlen(lexemaActual) >= tamActual){ //Si se acaba el espacio
            reservaLexema();
        }else{
            lexemaActual[strlen(lexemaActual)] = caracterActual;
            caracterActual = siguienteCaracter();
        }
    }while(isalnum(caracterActual));    //Mientras sea alfanumerico
    
    if(ispunct(caracterActual)){ //Por si hay un simbolo que no es un espacio
        cAnterior = caracterActual;
    }
}

void string(){
    do{
        if(strlen(lexemaActual) == tamActual){
            reservaLexema();
        }else{
            if(caracterActual == '\\'){
                caracterActual = siguienteCaracter();   //Coge las comillas escapadas
                lexemaActual[strlen(lexemaActual)] = caracterActual;
                
                caracterActual = siguienteCaracter();
                if(caracterActual != '"')//Coge el caracter siguiente a esas comillas
                    lexemaActual[strlen(lexemaActual)] = caracterActual;
            }else{
                lexemaActual[strlen(lexemaActual)] = caracterActual;
                caracterActual = siguienteCaracter();
            }
        }
    }while(caracterActual != '"');
    lexemaActual[strlen(lexemaActual)]='"';
}

void comentarioUnaLinea(){ //Comentarios de una unica linea
    
    do{
        if(strlen(lexemaActual) >= tamActual){
            reservaLexema();
        }else{
            lexemaActual[strlen(lexemaActual)] = caracterActual;
            caracterActual = siguienteCaracter();
        }
    }while(caracterActual != '\n');
}

void comentarioMulti(){ //Funcion que reconoce comentarios multilinea
    int condicion1 = 1, condicion2 = 1;
    do{
        if(strlen(lexemaActual) == tamActual){
            reservaLexema();
        }else{
            lexemaActual[strlen(lexemaActual)] = caracterActual;
            caracterActual = siguienteCaracter();
            if(caracterActual == '*'){
                condicion1=0;
            }
            if(!condicion1){
                if(caracterActual == '/')
                    condicion2=0;
                else
                    condicion1=1;
            }
            
            
        }
    }while(condicion2);
    lexemaActual[strlen(lexemaActual)] = caracterActual;
}

tabla nextCompLex(tabla *T){
    int codigo, tam;
    if(nodo != NULL){
        free(nodo);
        nodo=NULL;
    }
    lexemaActual = (char*) malloc (TAM*sizeof(char));
    free(lexemaActual);
    lexemaActual = (char*) malloc (TAM*sizeof(char));
    
    if(cAnterior != '\0'){ //Esto es por si se debe ir hacia atras en los caracteres leidos
        caracterActual = cAnterior;
        cAnterior = '\0';
    }else
        caracterActual = siguienteCaracter();
    
    tamActual=TAM;
    
    if(isalpha(caracterActual) || caracterActual == '_'){
        alfaNum();
        codigo = busca(T, lexemaActual);
        creaNodo(&nodo, lexemaActual, codigo);
        free(lexemaActual);
        return nodo;
    }else if(isspace(caracterActual)){
        creaNodo(&nodo, lexemaActual, SPACE);
        free(lexemaActual);
        return nodo;
    }else if(caracterActual == '"'){
        string();
        creaNodo(&nodo, lexemaActual, STRING);
        return nodo;
    }else if(ispunct(caracterActual)){
        lexemaActual[0] = caracterActual;
        switch(caracterActual){
            case '<':
                caracterActual=siguienteCaracter();
                if(caracterActual == '='){
                    lexemaActual[1] = caracterActual;
                    creaNodo(&nodo, lexemaActual, MENORIGUAL);
                    return nodo;
                }
                else if( caracterActual == '-'){
                    lexemaActual[1] = caracterActual;
                    creaNodo(&nodo, lexemaActual, ASIGNACION);
                    return nodo;
                }
                else
                    cAnterior = caracterActual;
                break;
            case '>':
                caracterActual=siguienteCaracter();
                if(caracterActual == '='){
                    lexemaActual[1] = caracterActual;
                    creaNodo(&nodo, lexemaActual, MAYORIGUAL);
                    return nodo;
                }
                else
                    cAnterior = caracterActual;
                break;
            case '=':
                caracterActual = siguienteCaracter();
                if(caracterActual == '='){
                    lexemaActual[1] = caracterActual;
                    creaNodo(&nodo, lexemaActual, IGUALIGUAL);
                    return nodo;
                }else
                    cAnterior = caracterActual;
                break;
            case ':':
                caracterActual = siguienteCaracter();
                if(caracterActual == '='){
                    lexemaActual[1] = caracterActual;
                    creaNodo(&nodo, lexemaActual, IGUALIGUAL);
                    return nodo;
                }else
                    cAnterior = caracterActual;
                break;
            case '/':
                caracterActual = siguienteCaracter();
                if(caracterActual == '/'){
                    comentarioUnaLinea();
                    creaNodo(&nodo, lexemaActual, COMENTARIO);
                    free(lexemaActual);
                    return nodo;
                }else if(caracterActual == '*'){
                    comentarioMulti();
                    creaNodo(&nodo, lexemaActual, COMENTARIO);
                    free(lexemaActual);
                    return nodo;
                }else
                    cAnterior = caracterActual;
                break;
                
        }
        creaNodo(&nodo, lexemaActual, caracterActual);
        return nodo;
    }
    
    
}