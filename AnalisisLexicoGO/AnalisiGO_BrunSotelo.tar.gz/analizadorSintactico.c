#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "definiciones.h"
#include "tablaSimbolos.h"
#include "analizadorLexico.h"

void iniciarAnalisis(){
    tabla T;
    tabla resultado;
    
    crea(&T);
    printf("--Comienzo del analisis--\n");
    while((resultado=nextCompLex(&T)) != NULL){
        int codigo = getCodigo(resultado);
        if(codigo != SPACE){
            size_t tam = strlen(getLexema(resultado));
            char *lexema = (char*)malloc(tam*sizeof(char));
            free(lexema);
            lexema = (char*)malloc(tam*sizeof(char));
            strncpy(lexema, getLexema(resultado), tam);

            printf("< %s, %d>\n", lexema, codigo);
            
        }
        //free(resultado); //Si pongo este free aqui peta por double_free core dumped
    }
    //printf("\n----------Impresion de la tabla de simbolos--------\n");
    //imprimir(T);
    
}

