#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "sistemaEntrada.h"
#include "tablaSimbolos.h"
#include "analizadorSintactico.h"

/*
 Analizador lexico para el lenguaje GO 
 */
int main(int argc, char** argv) {
    
    iniciarAnalisis();
    
    return (EXIT_SUCCESS);
}

