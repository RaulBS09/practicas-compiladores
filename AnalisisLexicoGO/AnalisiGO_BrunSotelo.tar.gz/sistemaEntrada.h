char siguienteCaracter();
