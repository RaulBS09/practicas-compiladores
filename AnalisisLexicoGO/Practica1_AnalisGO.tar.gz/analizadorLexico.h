#include "tablaSimbolos.h"

tabla nextCompLex(tabla *T);

