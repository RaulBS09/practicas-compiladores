#ifndef GESTORERRORES_H
#define GESTORERRORES_H

void errorAbrirArchivo(char* nombre);

void errorNumMal(char* lexema);

void errorComillas(char* lexema);
void errorComentario(char* lexema);

#endif /* GESTORERRORES_H */

